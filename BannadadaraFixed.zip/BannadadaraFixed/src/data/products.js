const products = [
  { id: 1, name: "Reversible Tote Bag", category: "Bags", price: 500 },
  { id: 2, name: "Box Bag (Plain)", category: "Bags", price: 350 },
  { id: 3, name: "Box Bag (Patch-work)", category: "Bags", price: 500 },
  { id: 4, name: "Sling Bag – String", category: "Bags", price: 150 },
  { id: 5, name: "Sling Bag – Regular", category: "Bags", price: 250 },
  { id: 6, name: "Sling Bag – Medium", category: "Bags", price: 450 },
  { id: 7, name: "Patch-work Bag (S)", category: "Bags", price: 250 },
  { id: 8, name: "Patch-work Bag (L)", category: "Bags", price: 550 },
  { id: 9, name: "Laptop Bag", category: "Bags", price: 800 },
  { id: 10, name: "Potli Bag", category: "Bags", price: 250 },
  { id: 11, name: "Grocery Bag (Foldable)", category: "Bags", price: 250 },

  { id: 12, name: "U-Shape Pouch (S)", category: "Pouches", price: 100 },
  { id: 13, name: "Trapezium Pouch", category: "Pouches", price: 100 },
  { id: 14, name: "Travel Kit", category: "Pouches", price: 170 },
  { id: 15, name: "Pad Holder", category: "Pouches", price: 100 },
  { id: 16, name: "Flat Pouch", category: "Pouches", price: 80 },
  { id: 17, name: "Box Pouch", category: "Pouches", price: 170 },
  { id: 18, name: "Trinket Pouch", category: "Pouches", price: 40 },

  { id: 19, name: "A4 File", category: "Stationery", price: 200 },
  { id: 20, name: "Stationery Pouch", category: "Stationery", price: 100 },
  { id: 21, name: "Embroidered Book", category: "Stationery", price: 450 },

  { id: 22, name: "Cutlery Kit", category: "Accessories", price: 260 },
  { id: 23, name: "Cloth Mask", category: "Accessories", price: 50 },

  { id: 24, name: "Patch-work Quilt", category: "Decor", price: "On request" },
  { id: 25, name: "Patch-work Table Cloth", category: "Decor", price: "On request" }
];

export default products;
